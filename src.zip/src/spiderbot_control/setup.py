from setuptools import setup, find_packages
from glob import glob
import os

package_name = 'spiderbot_control'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.py')),
        ('share/' + package_name + '/models', glob('models/*')),
    ],
    install_requires=['setuptools', 'numpy'],
    zip_safe=True,
    maintainer='teja',
    maintainer_email='teja@example.com',
    description='CPG+RL controller for spiderbot',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # lets you do: ros2 run spiderbot_control cpgrl_controller
            'teleop_keyboard = spiderbot_control.teleop_keyboard:main',
            'serial_bridge_jointstate = spiderbot_control.serial_bridge_jointstate:main',
            'policy_cpg_node = spiderbot_control.policy_cpg_node:main',
            "cpg=spiderbot_control.cpg:main",
            "diagnose_joint_mapping=spiderbot_control.diagnose_joint_mapping:main",
            'policy_omni_node = spiderbot_control.policy_omni_node:main',
            "fk=spiderbot_control.fk:main",
            "control=spiderbot_control.control:main",
        ],
    },
)
